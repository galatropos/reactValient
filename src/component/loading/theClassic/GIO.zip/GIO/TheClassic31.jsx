import React from "react";

const TheClassic31 = ({ text = "Loading..." }) => (
  <>
    <style>{`
      .loader {
        --w:10ch;
        font-weight: bold;
        font-family: monospace;
        font-size: 30px;
        line-height: 2em;
        letter-spacing: var(--w);
        width:var(--w);
        overflow: hidden;
        white-space: nowrap;
        color: #0000;
        text-shadow:
          calc( 0*var(--w)) 0 #000,calc(-1*var(--w)) 0 #000,calc(-2*var(--w)) 0 #000,calc(-3*var(--w)) 0 #000,calc(-4*var(--w)) 0 #000,
          calc(-5*var(--w)) 0 #000,calc(-6*var(--w)) 0 #000,calc(-7*var(--w)) 0 #000,calc(-8*var(--w)) 0 #000,calc(-9*var(--w)) 0 #000;
        animation: l31 1s infinite cubic-bezier(0.5,-150,0.5,150);
      }
      .loader:before {
        content:"${text}";
      }
      @keyframes l31{
        15%,100% {
          text-shadow:
            calc( 0*var(--w) + 0.1px) 0 #000,calc(-1*var(--w)) 0.01em #000,calc(-2*var(--w) - 0.2px) 0 #000,calc(-3*var(--w) + 0.1px) 0.01em #000,calc(-4*var(--w)) -0.01em #000,
            calc(-5*var(--w) - 0.1px) 0 #000,calc(-6*var(--w) - 0.2px) 0.015em #000,calc(-7*var(--w) - 0.1px) 0.02em #000,calc(-8*var(--w)) -0.01em #000,calc(-9*var(--w) + 0.2px) -0.01em #000;
        }
      }
    `}</style>
    <div className="loader" />
  </>
);

export default TheClassic31;
