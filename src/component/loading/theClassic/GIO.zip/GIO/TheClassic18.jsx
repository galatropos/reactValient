import React from "react";

const TheClassic18 = ({ text = "Loading..." }) => (
  <>
    <style>{`
      .loader {
        --w:10ch;
        font-weight: bold;
        font-family: monospace;
        font-size: 30px;
        letter-spacing: calc(10*var(--w));
        width: var(--w);
        overflow: hidden;
        white-space: nowrap;
        color: #0000;
        animation: l18 3s infinite;
      }
      .loader:before {
        content: "${text}";
      }
      @keyframes l18 {
        0% {text-shadow: calc(  9*var(--w)) 0 #000,calc( -1*var(--w)) 0 #000,calc(-11*var(--w)) 0 #000,calc(-21*var(--w)) 0 #000,calc(-31*var(--w)) 0 #000, calc(-41*var(--w)) 0 #000,calc(-51*var(--w)) 0 #000,calc(-61*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        4% {text-shadow: calc(  0*var(--w)) 0 #000,calc( -1*var(--w)) 0 #000,calc(-11*var(--w)) 0 #000,calc(-21*var(--w)) 0 #000,calc(-31*var(--w)) 0 #000, calc(-41*var(--w)) 0 #000,calc(-51*var(--w)) 0 #000,calc(-61*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        8% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-11*var(--w)) 0 #000,calc(-21*var(--w)) 0 #000,calc(-31*var(--w)) 0 #000, calc(-41*var(--w)) 0 #000,calc(-51*var(--w)) 0 #000,calc(-61*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        12% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-21*var(--w)) 0 #000,calc(-31*var(--w)) 0 #000, calc(-41*var(--w)) 0 #000,calc(-51*var(--w)) 0 #000,calc(-61*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        16% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-31*var(--w)) 0 #000, calc(-41*var(--w)) 0 #000,calc(-51*var(--w)) 0 #000,calc(-61*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        20% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-41*var(--w)) 0 #000,calc(-51*var(--w)) 0 #000,calc(-61*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        24% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-51*var(--w)) 0 #000,calc(-61*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        28% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-61*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        32% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-71*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        36% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-81*var(--w)) 0 #000}
        40%,60% {text-shadow: calc(  0*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        64% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-10*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        68% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-20*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        72% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-29*var(--w)) 0 #000,calc(-30*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        76% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-29*var(--w)) 0 #000,calc(-39*var(--w)) 0 #000,calc(-40*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        80% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-29*var(--w)) 0 #000,calc(-39*var(--w)) 0 #000,calc(-49*var(--w)) 0 #000, calc(-50*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        84% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-29*var(--w)) 0 #000,calc(-39*var(--w)) 0 #000,calc(-49*var(--w)) 0 #000, calc(-59*var(--w)) 0 #000,calc(-60*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        88% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-29*var(--w)) 0 #000,calc(-39*var(--w)) 0 #000,calc(-49*var(--w)) 0 #000, calc(-59*var(--w)) 0 #000,calc(-69*var(--w)) 0 #000,calc(-70*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        92% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-29*var(--w)) 0 #000,calc(-39*var(--w)) 0 #000,calc(-49*var(--w)) 0 #000, calc(-59*var(--w)) 0 #000,calc(-69*var(--w)) 0 #000,calc(-79*var(--w)) 0 #000,calc(-80*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        96% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-29*var(--w)) 0 #000,calc(-39*var(--w)) 0 #000,calc(-49*var(--w)) 0 #000, calc(-59*var(--w)) 0 #000,calc(-69*var(--w)) 0 #000,calc(-79*var(--w)) 0 #000,calc(-89*var(--w)) 0 #000,calc(-90*var(--w)) 0 #000}
        100% {text-shadow: calc(-9*var(--w)) 0 #000,calc(-19*var(--w)) 0 #000,calc(-29*var(--w)) 0 #000,calc(-39*var(--w)) 0 #000,calc(-49*var(--w)) 0 #000, calc(-59*var(--w)) 0 #000,calc(-69*var(--w)) 0 #000,calc(-79*var(--w)) 0 #000,calc(-89*var(--w)) 0 #000,calc(-99*var(--w)) 0 #000}
      }
    `}</style>
    <div className="loader" />
  </>
);

export default TheClassic18;
