import React from "react";

const TheClassic37 = ({ text = "Loading..." }) => (
  <>
    <style>{`
      .loader {
        font-weight: bold;
        font-family: monospace;
        display: inline-grid;
        font-size: 30px;
      }
      .loader:before,
      .loader:after {
        content:"${text}";
        grid-area: 1/1;
        -webkit-mask-size: 2ch 100%,100% 100%;
        -webkit-mask-repeat: no-repeat;
        -webkit-mask-composite: xor;
        mask-composite:exclude;
        animation: l37 1s infinite;
      }
      .loader:before {
        -webkit-mask-image:
          linear-gradient(#000 0 0),
          linear-gradient(#000 0 0);
      }
      .loader:after {
        -webkit-mask-image:linear-gradient(#000 0 0);
        transform: scaleY(0.5);
      }
      @keyframes l37{
        0%    {-webkit-mask-position:1ch  0,0 0}
        12.5% {-webkit-mask-position:100% 0,0 0}
        25%   {-webkit-mask-position:4ch  0,0 0}
        37.5% {-webkit-mask-position:8ch  0,0 0}
        50%   {-webkit-mask-position:2ch  0,0 0}
        62.5% {-webkit-mask-position:100% 0,0 0}
        75%   {-webkit-mask-position:0ch  0,0 0}
        87.5% {-webkit-mask-position:6ch  0,0 0}
        100%  {-webkit-mask-position:3ch  0,0 0}
      }
    `}</style>
    <div className="loader" />
  </>
);

export default TheClassic37;
